#include <SDL2/SDL.h>
#include <stdio.h>

int main(int argc, char *argv[]) {
    // ------------------------------
    // Déclarations SDL2 générales
    // ------------------------------
    SDL_Window *window = NULL;
   

    // ------------------------------
    // Déclarations SDL2_image
    // ------------------------------
   
   

    // ------------------------------
    // Déclarations SDL2_mixer
    // ------------------------------
   

    // ------------------------------
    // Déclarations SDL2_ttf
    // ------------------------------
  

    // ------------------------------
    // Variables de contrôle
    // ------------------------------
    int running = 1;
   
    SDL_Event event;

    // ------------------------------
    // Initialiser SDL2 (vidéo + audio)
    // ------------------------------
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) != 0) {
        printf("Erreur SDL_Init : %s\n", SDL_GetError());
        return 1;
    }

    // ------------------------------
    // Créer la fenêtre
    // ------------------------------
    window = SDL_CreateWindow(
        "Atelier SDL2 ",
        SDL_WINDOWPOS_CENTERED,
        SDL_WINDOWPOS_CENTERED,
        800, 600,
        SDL_WINDOW_SHOWN
    );
    if (!window) {
        printf("Erreur SDL_CreateWindow : %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }

    // ------------------------------
    // Créer le renderer
    // ------------------------------
   

    // ------------------------------
    // Initialiser SDL2_image et télécharger l'image
    // ------------------------------
   
    // ------------------------------
    // Initialiser SDL2_mixer
    // ------------------------------
   

    // ------------------------------
    // Initialiser SDL2_ttf
    // ------------------------------
    

    // ------------------------------
    // Boucle principale
    // ------------------------------
    while (running) {
        // ------------------------------
        // Gestion des événements
        // ------------------------------
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT)
                running = 0;

           
        }

        // ------------------------------
        // Effacer le renderer (fond blanc)
        // ------------------------------
        

        // ------------------------------
        // Afficher l'image sur tout l'écran
        // ------------------------------
       

        // ------------------------------
        // Afficher le texte si initi = 1
        // ------------------------------
       

        // ------------------------------
        // Mettre à jour l'écran (une seule fois)
        // ------------------------------
       
    }

    // ------------------------------
    // Libération des ressources
    // ------------------------------
    
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}


